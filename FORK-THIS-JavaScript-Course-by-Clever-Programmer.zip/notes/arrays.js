// Arrays stores items through indexes starting from 0
const colors = ["blue", "red", "yellow"]

// What does this print?
console.log(colors[0])

// How can we console log yellow from the array?