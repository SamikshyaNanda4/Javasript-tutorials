// Go to the link below 👇

// https://replit.com/@cleverprogrammer/DOM-Manipulation-Lesson#index.html