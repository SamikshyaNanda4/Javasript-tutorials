// console.log('Hello Its Sam')
// console.log('Curricullum Vitae')
// //variables 
// sam = 'whats up'
// console.log(sam)
// words = 'How are you doing today? Its really nice to see you bro .Hope You have a great day'
// console.log(words)

// //OPERATORS
// food = Number(prompt('how much was the food'))
// tipPercentage=Number(prompt('tip percentage?'))/100
// console.log('Total Food Cost:',food)
// tipAmount=food * tipPercentage
// console.log('Tip Amount:',tipAmount)
// totalAmount=food+tipAmount;
// console.log('Total Amount:',totalAmount)
// //user input

// ..........................................................

//baby weather App
// if it rains ---grab umbrella
// if it doesnt rain --wear sunghlasses
// let weather=prompt('whats the weather')
// if(weather=='rain'){
//   console.log('GRAB YOUR UMBRELLA')
// }else{
//   console.log('GO WEAR YOUR SUNGLASSES')
// }

// ............................................................

// call=Number(Math.ceil(Math.random()*3))
// console.log(call)
// if(call==1){
//   console.log('STONE')
// }else if(call==2){
//   console.log('PAPER')
// }else{(console.log('SCISSOR'))
//      }
// ..............................................................


//functions
// function sayMyname(){
//   console.log('My name is Sam')
//    console.log('My name is Debi')
//    console.log('My name is Rohan')
//    console.log('My name is Sam')
// }
// sayMyname()
// ...................................................................

// function myName(anything){
//   console.log(anything)
// }

//   myName('SAM')



// function greeting(name) {
//   greet = 'Hi ' + name + ', Nice to meet you'
//   console.log(greet)
// }
// greeting('Samikshya')


//template literals ``
// function greetme(name) {
//   greet = `hi ${name},nice to meet you`
//   console.log(greet)
// }
// greetme("Samikshya Nanda")
// ............................................................

//function in which two numbers are taken as input
//return concept also present
// function sum(a,b){
//   //return a + b
//   return a + b
// }
// num1=sum(1,3)
// console.log(num1)

// ...................................................................
// function calculatetotal(food, tip){
// tipPercentage=tip/100
// tipAmount=food * tipPercentage
// totalAmount  = sum(food,tipAmount)
// return totalAmount
// }
// console.log(calculatetotal(300,20))
// console.log('Tip Amount:',tipAmount)
// console.log('Total Amount:',totalAmount)

................................................................

//ES6 way of function
//Arrow Function`
