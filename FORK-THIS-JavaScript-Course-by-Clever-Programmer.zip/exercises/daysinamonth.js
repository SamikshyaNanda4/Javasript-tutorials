// Test you code by forking this repl: 
// 👉 COMMING SOON!

// Create a function that takes the month and year (as integers)
// and returns the number of DAYS in that month

// Hints:
// Don't forget about leap year!
// Keep in mind which month has 30 days, 31 days, and 28 days
// Use everything you learned to get to the answer

const daysInMonth = (month,year) => {
  
}

// Example:
// daysInMonth(2,2018) -> 28
// days(4,654) -> 30
// days(2,2020) -> 29